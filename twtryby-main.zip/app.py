import os
from flask import Flask, redirect, render_template, request, session
from tweepy import errors
import tweepy
from dotenv import dotenv_values

os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"
AH = dotenv_values(".env")
REDIRECT = "http://127.0.0.1:5000/callback"

app = Flask("twtryby")

app.secret_key = """
    [Verse 1: Ecco2k]
    Now I'm on the head of the arrow
    And I'm the head of the fountain
    Come to think about it, I can't wrap my head around it
"""

auth_handler = tweepy.OAuth1UserHandler(consumer_key=AH["API_KEY"],consumer_secret=AH["API_SECRET"],callback=REDIRECT)

@app.route("/")
def index():
    try:
        session["access_token"]
        return redirect("ja")
    except KeyError:
        return render_template("index.html")

@app.route("/login")
def login():
    return redirect(auth_handler.get_authorization_url())

@app.route("/callback")
def callback():
    try:
        session["acess_token"], session["access_token_secret"] = auth_handler.get_access_token(request.args.get("oauth_verifier"))
    except errors.TweepyException:
        return redirect("/")

    #create or link acc in database
    return redirect("ja")

@app.route("/ja")
def ja():
    try:
        auth_handler.access_token = session["acess_token"]
        auth_handler.access_token_secret = session["access_token_secret"]
        usr = tweepy.API(auth_handler)
        verif = usr.verify_credentials()
        session["uid"] = verif.id
        return render_template("profile.html",username=verif.name)
    except errors.Forbidden:
        return redirect("logout")

@app.route("/logout")
def logout():
    session["acess_token"] = session["access_token_secret"] = None
    return redirect("/")

@app.route("/rybnik")
def rybnik():
    auth_handler.access_token = session["acess_token"]
    auth_handler.access_token_secret = session["access_token_secret"]
    usr = tweepy.API(auth_handler)
    tl = [[tweet.full_text,tweet.id_str] for tweet in usr.user_timeline(exclude_replies=True,include_rts=False,tweet_mode="extended")]
    #Returns an array [text, tweetId], tweet id will later be used for calling the throw API
    return render_template("rybnik.html", tweets=tl)

#### API SEC

@app.route("/api_throw/<id>")
def api_throw(id):
    return {"id": id}

if __name__ == "__main__":
    app.run(debug=True)